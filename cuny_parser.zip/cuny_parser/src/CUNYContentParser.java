import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class CUNYContentParser {
	
	private static String sourcePath = "C:\\Users\\Mehrdad\\Desktop\\CS410\\project\\";
	private static String baseUrl = "http://student.cuny.edu/cgi-bin/SectionMeeting/";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(sourcePath + "cuny.txt"));
			BufferedWriter wr = new BufferedWriter(new FileWriter(new File(sourcePath + "cuny_url.txt")));
			String line;
			String url = "";
			boolean isOnline = false;

			while ((line = br.readLine()) != null)
			{
				if(line.contains("whitebox") && !line.contains("bigwhitebox"))
				{
					url = readUrl(br);
				}
				else if(line.contains("bigwhitebox"))
				{
					isOnline = isOnline(br);
					if(isOnline)
					{
						wr.write(baseUrl + url + "\n");
					}
				}
			}
			wr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static String readUrl(BufferedReader br) throws IOException
	{
		String url;
		String line = br.readLine();
		int startIndex = line.indexOf("A HREF=") + 8;
		int endIndex = line.indexOf(">", startIndex) - 1;
		url = line.substring(startIndex, endIndex);
		while ((line = br.readLine()) != null && line.contains("whitebox"))	{ /* read all whitebox lines	*/ }
		return url;
	}
	
	private static boolean isOnline(BufferedReader br) throws IOException
	{
		boolean isOnline = false;
		int lineIndex = 1;
		String line;
		while ((line = br.readLine()) != null)
		{
			if(lineIndex == 6 )
			{
				int beginIndex = line.indexOf("bigwhitebox") + 13;
				int endIndex = line.indexOf("<", beginIndex);
				String res = line.substring(beginIndex, endIndex);
				isOnline = res.toLowerCase().equals("no") ? false : true;
				break;
			}
			if(line.contains("bigwhitebox"))
			{
				lineIndex++;
			}
		}

		return isOnline;
	}

}
