import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;


public class CUNYContentCleaner {
	
	private static String sourcePath = "C:\\Users\\Mehrdad\\Desktop\\CS410\\project\\cuny_pages\\";
	private static String destinationPath = "C:\\Users\\Mehrdad\\Desktop\\CS410\\project\\cuny_pages_clean\\";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int fileCounter = 13061;
		for(int i = 1 ; i <= 252 ; i++)
		{
			try 
			{
				String inputFile = sourcePath + "cuny_"+ i +".txt";
				// System.out.println("Clean: "+ i + " file");
				BufferedReader br = new BufferedReader(new FileReader(inputFile));
				String url = br.readLine();
				String line;
				String title = "";
				String desc = "";
				while ((line = br.readLine()) != null)
				{
					if(line.startsWith("COURSE TITLE"))
					{
						title = line.substring("COURSE TITLE:".length());
					}
					if(line.startsWith("COURSE DESCRIPTION"))
					{
						desc = br.readLine();
						BufferedWriter wr = new BufferedWriter(new FileWriter(new File(destinationPath + fileCounter + ".txt")));
						wr.write(url.trim() +"\n");
						wr.write(title.trim() +"\n");
						wr.write(desc.trim() +"\n");
						wr.close();
						fileCounter++;
						break;
					}
				}
			}
			catch (Exception e) 
			{
				System.out.println("Failed file: " + i);
				e.printStackTrace();
			}
		}
	}
}
