import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class StanfordContentCleaner {
	
	private static String sourcePath = "C:\\Users\\Mehrdad\\Desktop\\CS410\\project\\stanford_pages\\";
	private static String destinationPath = "C:\\Users\\Mehrdad\\Desktop\\CS410\\project\\stanford_pages_clean\\";
	
	
	private static boolean isEnded(String line)
	{
		return line.startsWith("Return to Stanford Online Course catalog") ||
				line.startsWith("FAQ") ||
				line.startsWith("ABOUT THE TEAM") ||
				line.startsWith("INSTRUCTOR");
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int fileCounter = 12941;
		for(int i = 460 ; i <= 579 ; i++)
		{
			if(fileCounter == 13035)
			{
				System.out.print(i);
			}
			try 
			{
				String inputFile = sourcePath + "page_"+ i +".txt";
				// System.out.println("Clean: "+ i + " file");
				BufferedReader br = new BufferedReader(new FileReader(inputFile));
				BufferedWriter wr = new BufferedWriter(new FileWriter(new File(destinationPath + fileCounter + ".txt")));
				String line = br.readLine(); 
				line = line.trim();
				wr.write(line +"\n");
				line = br.readLine();
				line = line.trim();
				wr.write(line +"\n");
				
				
				while ((line = br.readLine()) != null)
				{
					line = line.trim();
					if(line.contains("Course topic"))
					{
						wr.write(line +"\n");
						while ((line = br.readLine()) != null)
						{
							line = line.trim();
							if(line.trim().length() == 0 || line.trim() == "")
								continue;
							if(isEnded(line))
							{
								break;
							}
							wr.write(line +"\n");
						}
						break;
					}
				}
				wr.close();
			}
			catch (Exception e) 
			{
				System.out.println("Failed file: " + i);
				e.printStackTrace();
			}
			fileCounter++;
		}
	}
}
