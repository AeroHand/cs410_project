import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import org.apache.commons.io.FileUtils;

public class UIUCContentCleaner {
	private static String sourcePath = "C:\\Users\\Mehrdad\\Desktop\\CS410\\project\\uiuc_pages\\";
	private static String destinationPath = "C:\\Users\\Mehrdad\\Desktop\\CS410\\project\\uiuc_pages_clean\\";
	
	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {
		int emptyCounter = 0;
		int fileCounter = 5000;
		for(int i = 0; i <= 8178 ; i++)
		{
			try {
				String inputFile = sourcePath + "uiuc_"+ i +".txt";
				// System.out.println("Clean: "+ i + " file");
				String page = FileUtils.readFileToString(new File(inputFile));
				
				int startUrlIndex = page.indexOf("__url") + "__url".length() + 3;
				int endUrlIndex = page.indexOf(",", startUrlIndex) - 1;
				String url = page.substring(startUrlIndex, endUrlIndex);
				// System.out.println(url);
	
				int startTitleIndex = page.indexOf("cis-section-course portlet-padtop1") + "cis-section-course portlet-padtop1".length() + 3;
				int endTitleIndex = page.indexOf("</p>", startTitleIndex);
				String title = page.substring(startTitleIndex, endTitleIndex);
				// System.out.println(title);
				
				String desc = "";
				int startDescIndex = page.indexOf("subject-info1");
				if(startDescIndex > 0)
				{
					startDescIndex+= "subject-info1".length() + 3;
					int endDescIndex = page.indexOf("</div>", startDescIndex);
					desc = page.substring(startDescIndex, endDescIndex);
					desc = desc.substring(desc.indexOf("portlet-padtop10") + "portlet-padtop10".length());
					startDescIndex = desc.indexOf("portlet-padtop10") + "portlet-padtop10".length() + 3;
					endDescIndex  = desc.indexOf("</p>", startDescIndex);
					if(startDescIndex <= 0)
					{
						desc = "";
					}
					else
					{
						desc = desc.substring(startDescIndex, endDescIndex);
					}
				}
				
				String sameAs = "";
				int startSameAsIndex = page.indexOf("Same as");
				if(startSameAsIndex >= 0)
				{
					int endSameAsIndex  = page.indexOf("</p>", startSameAsIndex);
					sameAs = page.substring(startSameAsIndex, endSameAsIndex);
				}
				
				if(desc.trim().length() <= 0 && sameAs.trim().length() <= 0)
				{
					System.out.println("Empty file: " + i);
					emptyCounter++;
					continue;
				}
				// System.out.println(desc);
				BufferedWriter wr = new BufferedWriter(new FileWriter(new File(destinationPath + fileCounter + ".txt")));
				fileCounter++;
				wr.write(url +"\n");
				wr.write(title +"\n");
				wr.write(desc +"\n");
				wr.write(sameAs +"\n");
				wr.close();
				//System.out.println(content);
			}
			catch (Exception e) 
			{
				System.out.println("Failed file: " + i);
				emptyCounter++;
				e.printStackTrace();
			}
		}
		System.out.println("Total Empty and Error: " + emptyCounter);
	}
}